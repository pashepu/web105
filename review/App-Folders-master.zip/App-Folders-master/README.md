jQuery App-Folders
===========

Use jQuery to create iOS-like App Folders on any website. They can contain any content and be styled in any way.

* Works great on mobiles
* Responsive design
* Fully styleable (it's easy!)
* Well-documented 
* Very easy to use
* Can contain any content (images, text, video, complex layouts)
* Opened Folder can be linked to from other pages
* Configurable position changes for nth folder
